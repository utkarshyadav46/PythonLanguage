from tkinter import *    #Adding the graphics libraries from Tkinter
import os   
import PIL  #Adding the PIL library in the program for editing the images
from PIL import ImageFont
from PIL import Image
import tkinter.messagebox
from PIL import ImageDraw
from PIL import ImageTk
from chatterbot import ChatBot
from chatterbot.trainers import ListTrainer
from gtts import gTTS
'''import pyttsx
e = pyttsx.init()
e.say("Your Message")
e.runAndWait()'''
bot=ChatBot('BOT')
bot.set_trainer(ListTrainer)
while True:
    message =input('YOU:')
    if message.strip() != 'Bye':
        reply=bot.get_response(message)
        print('ChatBot:',reply) 
    elif message.strip() == 'Bye':
        print('ChatBot: Bye Bye')
        break
