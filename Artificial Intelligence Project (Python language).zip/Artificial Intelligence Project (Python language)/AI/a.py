from tkinter import *    #Adding the graphics libraries from Tkinter
import os   
import PIL  #Adding the PIL library in the program for editing the images
from PIL import ImageFont
from PIL import Image
import tkinter.messagebox
#import tkinter.tkfiledialog    
from PIL import ImageDraw
from PIL import ImageTk
#from Tkinter import *

creds = 'tempfile.temp'

def Signup():
	global pwordE
	global nameE
	global roots
	roots = Tk()
	roots.title('Signup')
	roots.geometry('500x500')
	instruction = Label(roots, text='   Please Enter new Credentials')
	instruction.grid(row=0, column=0, sticky=E)

	nameL = Label(roots, text='New Username: ')
	pwordL = Label(roots,text='New Password: ')
	nameL.grid(row=1, column=0, sticky=W)
	pwordL.grid(row=2, column=0, sticky=W)

	nameE = Entry(roots)
	pwordE = Entry(roots, show='*')
	nameE.grid(row=1, column=1)
	pwordE.grid(row=2, column=1)

	signupButton = Button(roots, text='Signup', command=FSSignup)
	signupButton.grid(columnspan=2, column=4, sticky=W)
	global nameEL
	global pwordEL
	#global rootA
	#rootA = Tk()
	#rootA.title('Login')
	#rootA.geometry('500x500')
	instruction = Label(roots, text='Please Login\n')
	instruction.grid(sticky=E)

	nameL = Label(roots, text='Username: ')
	pwordL = Label(roots, text='Password: ')
	nameL.grid(row=5, sticky=W)
	pwordL.grid(row=6, sticky=W)

	nameEL = Entry(roots)
	pwordEL = Entry(roots, show='*')
	nameEL.grid(row=5, column=1)
	pwordEL.grid(row=6, column=1)

	loginB = Button(roots, text='Login', command=CheckLogin)
	loginB.grid(columnspan=2, column=4, sticky=W)

	rmuser = Button(roots, text='Delete User', fg='red', command=DelUser)
	rmuser.grid(columnspan=2, sticky=W)
	roots.mainloop()

def FSSignup():
	with open(creds, 'w') as f:
		f.write(nameE.get())	
		f.write('\n')
		f.write(pwordE.get())
		f.close()

	roots.destroy()
	Signup()


def CheckLogin():
	with open(creds) as f:
		data = f.readlines()
		uname = data[0].rstrip()
		pword = data[1].rstrip()

	if nameEL.get() == uname and pwordEL.get() == pword:
		r = Tk()
		r.title(':CHAT BOX')
		r.geometry('500x500')
		rlbl = Label(r, text='\n[+] Logged In')
		rlbl.pack()
		r.mainloop()
	else:
		r = Tk()	
		r.title('D:')
		r.geometry('150x50')
		rlbl = Label(r, text='\n[! Invalid Login Try Again')
		loginB = Button(r, text='Login Again ', command=Signup)
		loginB.grid(columnspan=2, column=4, sticky=W)
		rlbl.pack()
		r.mainloop()	

def DelUser():
	os.remove(creds)
	rootA.destroy()
	Signup()

if os.path.isfile(creds):
        Signup()
else:
	Signup()
