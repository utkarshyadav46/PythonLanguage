from tkinter import *    #Adding the graphics libraries from Tkinter
import os   
import PIL  #Adding the PIL library in the program for editing the images
from PIL import ImageFont
from PIL import Image
import tkinter.messagebox
from PIL import ImageDraw
from PIL import ImageTk
from chatterbot import ChatBot
from chatterbot.trainers import ListTrainer
from gtts import gTTS
'''import pyttsx
e = pyttsx.init()
e.say("Your Message")
e.runAndWait()'''
bot=ChatBot('BOT')
bot.set_trainer(ListTrainer)
for files in os.listdir('C:/Users/Utkarsh Yadav\Desktop\AI\chatterbot-corpus-master\chatterbot-corpus-master\chatterbot_corpus\data\english/'):
    data=open('C:/Users/Utkarsh Yadav\Desktop\AI\chatterbot-corpus-master\chatterbot-corpus-master\chatterbot_corpus\data\english/'+files,'r').readlines()
    bot.train(data)
while True:
    message =input('YOU:')
    if message.strip() != 'Bye':
        reply=bot.get_response(message)
        print('ChatBot:',reply)
        tts=gTTS(text=reply,lang='en')
        tts.save('msg.mp3')
        os.system('msg.mp3')   
    if message.strip() == 'Bye':
        print('ChatBot: Bye Bye')
        break
