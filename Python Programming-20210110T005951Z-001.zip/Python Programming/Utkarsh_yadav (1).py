#code challenge 1
print "Twinkle, twinkle, little star,\n\tHow I wonder what you are!\n\t\tUp above the world so high,\n\t\tLike a diamond in the sky.\nTwinkle,twinkle,little star,\n  How I wonder what you are"
