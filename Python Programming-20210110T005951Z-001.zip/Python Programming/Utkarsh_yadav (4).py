#code challenge 4
str=raw_input("enter any string\n")       #to take input from user
#print str
first,last=str.split(" ")               #to split the entire string on  basis of space
print last+" "+first 
#print str[a+1:]+" " +str[0:a]               
