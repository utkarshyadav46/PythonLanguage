#code challenge submission 03
import time
print "Current date and time :\n" +time.strftime("%x")+ " " +time.strftime("%X") 
