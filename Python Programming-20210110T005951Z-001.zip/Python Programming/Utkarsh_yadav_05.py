#code challenge 01
name=raw_input("\nenter the numbers seperated by comma")
x=[]
y=()
x=name.split(",")
y=name.split(",")
print "list:", x
print "tuple", y
