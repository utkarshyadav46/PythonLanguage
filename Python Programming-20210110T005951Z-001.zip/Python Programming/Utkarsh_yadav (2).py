#code submission 02
import sys                                #import is similar to include in c allow user to use standard library
print (sys.version)                       #function defined in module     
